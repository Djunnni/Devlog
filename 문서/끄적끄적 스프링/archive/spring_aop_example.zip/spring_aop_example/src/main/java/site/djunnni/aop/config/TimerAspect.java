package site.djunnni.aop.config;


import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class TimerAspect {

    @Pointcut("@annotation(site.djunnni.aop.annotation.Timer)")
    private void enableTimer() {}

    @Around("enableTimer()")
    public void around(ProceedingJoinPoint joinPoint) throws Throwable {
        StopWatch stopWatch = new StopWatch();

        System.out.println("stopWatch 시작");
        stopWatch.start();

        joinPoint.proceed();

        stopWatch.stop();
        System.out.println("stopWatch 종료");
        System.out.println("총 걸린 시간: "+ stopWatch.getTotalTimeMillis());
    }
}
