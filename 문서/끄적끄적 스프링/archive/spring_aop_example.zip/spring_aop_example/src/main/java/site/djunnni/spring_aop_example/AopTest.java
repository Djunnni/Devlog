package site.djunnni.spring_aop_example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import site.djunnni.util.Utility;

public class AopTest {
    public static void main(String[] args) throws InterruptedException {
        ApplicationContext context = new ClassPathXmlApplicationContext("aop.xml");
        Utility util = context.getBean("utility",Utility.class);
        util.wait(3);
    }
}
