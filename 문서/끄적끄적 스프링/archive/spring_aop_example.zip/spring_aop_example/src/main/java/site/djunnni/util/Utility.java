package site.djunnni.util;

import org.springframework.stereotype.Component;
import site.djunnni.aop.annotation.Timer;

@Component
public class Utility {
    @Timer
    public void wait(int sec) throws InterruptedException {
        System.out.println("기다리기 시작한다?");
        Thread.sleep(sec * 1000);
        System.out.println("기다리기 끝");
    }
}
